import java.io.Serializable;

@entity
public class Tecnico implements Serializable {

	@Id

	 private Long codigo ;
	 private String nome ;
	 private String telefone;



	 private Float area ;

	

	 @OneToMany 
	 ( mappedBy ="time", targetEntity = Time.class)

		
	

	}


