import java.io.Serializable;



@entity
public class Atleta implements Serializable {

	@Id

	 private Long codigo1 ;
	 private String nome ;
	 private String esporte ;
	 private String peso ;
	 private String altura ;
	 private String telefone;

 

	 private Float area ;

	

	 @OneToMany 
	 ( mappedBy ="time", targetEntity = Time.class)

	


}
